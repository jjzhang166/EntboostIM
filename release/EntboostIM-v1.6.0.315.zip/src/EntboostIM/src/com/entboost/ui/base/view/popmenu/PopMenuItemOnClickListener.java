package com.entboost.ui.base.view.popmenu;

public interface PopMenuItemOnClickListener {
	public void onItemClick();
}
